import 'package:flutter/material.dart';

const Color kDarkBlue = Color(0xFF090943);
